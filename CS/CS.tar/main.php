<HTML>
<FRAMESET BORDER="0" FRAMEBORDER="0" COLS="23%,*">
  <FRAME SCROLLING="no" SRC="menu.php" NAME="menu"> 
  <FRAME SRC="select_course.php" NAME="main">
</FRAMESET>
</HTML>
