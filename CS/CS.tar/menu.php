<!DOCTYPE HTML PUBLIC "-//IETF//DTD HTML//EN">
<HTML>
<HEAD>
   <TITLE>COE Laboratory Inventory</TITLE>
</HEAD>
<BODY BGCOLOR="#aaccff" alink="blue" vlink="blue">
<center>
<P>
  <IMG SRC="http://www.engr.sjsu.edu/images/jpgs/sjsu-coe.jpg">
</P>
<H3 ALIGN="center">Client/Server Student Information</H3>
<HR>
<BR><a href="select_course.php" target="main">Select A Course</a><BR>
<BR><a href="student_list.php" target="main">All Student Info</a><BR>
<BR><a href="search_name.php" target="main">Search By Name</a><BR>
<BR><a href="search_ssn.php" target="main">Seach By SSN</a><BR>
<BR><a href="http://dolphin.engr.sjsu.edu" target="_top">Back to ECS Menu</a><BR>

<BR>
<HR>
</center>
</BODY>
</HTML>
