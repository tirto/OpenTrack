#! /usr/bin/perl -w

use DBI;
use CGI qw/:standard :html3 *table *center/;
use FindBin qw($Bin);
use lib "$Bin/../Common";
use infolib;
use misclib;
use 5.004;

# Projects: Job Tracking System
# File:     requestMain.pl
# By:       Prasanth Kumar
# Date:     Jun 22, 2000

# Description:
# Handles user job request form. Depending of which parameters are
# passed in, different portions of the form are printed as noted below.

# Parameters passed in:
#  firstname    blank => print_name_form()
#  lastname     blank => print_name_form()
#  firstname    invalid => print_name_form(invalid)
#  lastname     invalid => print_name_form(invalid)
#  machine_type blank => print_query_form()
#  OS           blank => print_query_form()
#  description  blank => print_query_form(invalid)

# ChangeLog:
# 06/16/2000 Prasanth Kumar
# - cleaned up file formatting
# 06/20/2000 Prasanth Kumar
# - do hashed matches
# - make parts query form noneditible
# - autodetect machine type and OS
# - started using frames
# 06/29/2000 Prasanth Kumar
# - move infolib.pm and misclib.pm modules into
#   the ../Common directory
# 07/20/2000 Prasanth Kumar
# - resize request field to 1000 characters
# 08/14/2000 Prasanth Kumar
# - fix prepare statements to not interpolate parameters.
# 10/31/2000 Prasanth Kumar
# - added SUN machines to list
# 12/14/2000 Prasanth Kumar
# - cleaned up form
# 02/16/2001 Prasanth Kumar
# - changed header to no-cache
# 05/09/2001 Prasanth Kumar
# - started addition of categories field

# TODO:
# - add simple purchase order feature

BEGIN
{
  $ENV{ORACLE_HOME} = "/projects/oracle";
  $ENV{ORACLE_SID} = "rdb1";
}

########## DEFINE SOME CONSTANTS ##########
# list of valid machine types
my @MACHINES = ('None', 'PC', 'Mac', 'DEC5000', 'DEC5100',
		'HP XTerminal',	'HP9000', 'RS/6000', 'MIPS',
		'IBM Powerstation', 'Sun', 'Other');

# form a hash of machine types for fast matches
my %MACHINES;
for (@MACHINES) { $MACHINES{$_} = 1 }

# list of valid OS types
my @OSYS = ('None', 'Win3.1', 'Win95', 'Win98', 'WinNT',
	    'MacOS', 'Linux', 'Unix', 'AIX', 'Solaris',
	    'Irix', 'Ultrix', 'BSD', 'HP UX', 'Other');

# form a hash of OS types for fast matches
my %OSYS;
for (@OSYS) { $OSYS{$_} = 1 }

# list of valid buildings. The keys are from the name database
# while the values are full names used in the job database
my %BUILDINGS = ('ENG' => 'College of Engineering',
		 'IS' => 'Industrial Studies',
		 'AB' => 'Aviation');

################ PRINT HEADER AND START TO FORMAT HTML #############
print header(-pragma=>'no-cache'),
    start_html(-title=>'Job Request System', -bgcolor=>'white'), "\n";

if (param()) {
    my %valuepairs; # holds validated input parameters
    
    # cleanup and format names for a database search
    my $firstname = trim_spaces( param("firstname"));
    my $lastname = trim_spaces(param("lastname"));
    my $search = $firstname . "_and_" . $lastname; 

    # query the name databse by name and validate
    my ($err, $result) = SearchByName($search); 

    if ($err == 1) {
	print_name_form("First name field is missing.");
    } elsif ($err == 2) {
	print_name_form("Last name field is missing.");
    } elsif ($err == 3) {
	print_name_form("The first and last name fields are missing.");
    } elsif ($err == 4) {
	print_name_form("That name was not found in the database!");
    } else {
	my $ref_ary = $result->[0];
	my $machine_type = param("machine_type");
	my $OS = param("OS");
	my $description = param("description");
	my $validated = 0;

	# extract validated data for this person
	$valuepairs{"firstname"} = $ref_ary->[1];
	$valuepairs{"lastname"} = $ref_ary->[2];
	$valuepairs{"email"} = $ref_ary->[4];
	$valuepairs{"phone"} = substr($ref_ary->[11],2,4);
	$valuepairs{"building"} = $BUILDINGS{$ref_ary->[12]};
	$valuepairs{"room"} = $ref_ary->[13];
	$valuepairs{"category"} = param("category");
	
	# validate OS or reset to a guessed value from client
	if ($OSYS{$OS}) {
	    $validated++;
	} else {
	    $OS = guess_os(user_agent());
	}
	$valuepairs{"OS"} = $OS;

	# validate machine type or reset to default
	if ($MACHINES{$machine_type}) {
	    $validated++;
	} else {
	    $machine_type = guess_machine(user_agent());
	}
	$valuepairs{"machine_type"} = $machine_type;

	# validate length of description
	$valuepairs{"description"} = $description;
	if ($validated == 2) {
	    if ($description eq '') {
		print_query_form(\%valuepairs,
				 "Please fill in the request field.");
	    } elsif ($description =~ /^.{0,1000}$/s) {
		update_database(\%valuepairs);
	    } else {
		print_query_form(\%valuepairs,
				 "Please limit the request field to under 1000 characters.");
	    }
	} else {
	    print_query_form(\%valuepairs);
	}
    }   
} else {
    print_name_form();
}  

print end_html;

########## END OF MAIN ##########

########## PRINT THE NAME REQUEST FORM ##########
sub print_name_form {
# Description: display a page requesting the name.
# Input: warning message.
# Output: none.

    print h3({-align=>'center'}, "Job Request Login"),
    "This is the COE job request form to be used by the ",
    "faculty and staff of the SJSU College of Engineering. ",
    "Please enter your <B>First and Last Name</B> so that ",
    "that the system can proceed with your service request. ",
    "If you have trouble locating your name, please search ",
    "the <I>COE Information System</I> in the menu to the ",
    "left or contact <I>Donna Frank-Dunton</I>, the database ",
    "administrator, at x3978 if your name is missing.",
    "<br><br>";

    # Print any error messages if they exist.
    if (@_) {
	print "<center>", font({-color=>'red'}, @_), "</center>";
    }
    
    print start_form;
    print table({-align=>'center', -border=>0, -cellspacing=>5},
		Tr(td({-align=>'right'}, "First name:"),
		   td(textfield(-name=>"firstname", -default=>'',
				-size=>16, -maxlength=>16)),
		   td({-align=>'right'}, "Last name:"),
		   td(textfield(-name=>"lastname", -default=>'',
				-size=>16, -maxlength=>16))),
		Tr(td({-align=>'center', -colspan=>4},
		      submit(-name=>'search', -label=>'Proceed')))); 
    print end_form;

} # print_name_form

########## PRINT THE QUERY FORM ##########
sub print_query_form {
# Description: display the query form.
# Input: validated values and warning message.
# Output: none.

    my %valuepairs = %{shift(@_)};
    my $dbh = open_database("/home/httpd/.jobDBAccess");

    my $category_table = get_category_table($dbh);
    
    print h3({-align=>'center'}, "Job Request Entry"), "\n";

    # Print any error messages if they exist.
    if (@_) {
	print "<center>", font({-color=>'red'}, @_), "</center>";
    }

    print start_form(),
    table({-align=>'center', -cellspacing=>0,
	   -cellpadding=>5, -border=>1}, "\n",
	  Tr(td({-bgcolor=>'#CCEEFF'},"Requester"),
	     td({-colspan=>3},$valuepairs{"firstname"} . " " . $valuepairs{"lastname"})), "\n",
	  Tr(td({-bgcolor=>'#CCEEFF'},"Phone"),
	     td($valuepairs{"phone"}), "\n",
	     td({-bgcolor=>'#CCEEFF'},"Email"),
	     td($valuepairs{"email"})), "\n",
	  Tr(td({-bgcolor=>'#CCEEFF'},"Building"), "\n",
	     td($valuepairs{"building"}),
	     td({-bgcolor=>'#CCEEFF'},"Room Number"),
	     td($valuepairs{"room"}))), "\n",
    table({-align=>'center', -cellspacing=>2,
	   -cellpadding=>2, -border=>0}, "\n",
	  Tr(td({-align=>'right'},"Machine Type:"),
	     td({-align=>'left'},
		popup_menu(-name=>"machine_type",-values=>\@MACHINES,
			   -default=>$valuepairs{"machine_type"})), "\n",
	     td({-align=>'right'},"OS:"),
	     td({-align=>'left'},
		popup_menu(-name=>"OS",-values=>\@OSYS,
			   -default=>$valuepairs{"OS"}))), "\n",
	  Tr(td({-align=>'right'}, "Category:"),
	     td({-align=>'left', -colspan=>3}, "\n",
		popup_menu(-name=>"category",
			   -labels=>$category_table,
			   -values=>[ sort { $category_table->{$a} cmp $category_table->{$b} } keys %$category_table ],
			   -default=>1)))), "\n",
    table({-align=>'center', -cellspacing=>5,
	   -cellpadding=>0, -border=>0}, "\n",
	  Tr(td({-align=>'left'},
		"Describe your request: (Note: mandatory field, less than 1000 characters.)")), "\n",
	  Tr(td({-align=>'center'},
		textarea(-name=>"description",
			 -rows=>10, -columns=>60,
			 -wrap=>'virtual',
			 -default=>$valuepairs{"description"})))), "\n",
    hidden(-name=>'firstname', -value=>$valuepairs{"firstname"}), "\n",
    hidden(-name=>'lastname', -value=>$valuepairs{"lastname"}), "\n";

    # optional fields for simple parts ordering
#      print start_table({-align=>'center', -border=>0,
#  		       -cellspacing=>5, -cellpadding=>0});
#      print Tr(td({-colspan=>2},
#  		"Use the following optional fields for making a simple purchase request."));
#      print Tr(td({-align=>'right'}, "Item Description:"),
#  	     td(textfield({-name=>'itemdesc', -size=>40,
#  		    -maxlength=>64}))),
#      Tr(td({-align=>'right'}, "Vendor:"),
#         td(textfield({-name=>'itemvendor', -size=>32,
#  		     -maxlength=>32}))),
#      Tr(td({-align=>'right'}, "Vendor Contact:"),
#         td(textfield({-name=>'itemcontact', -size=>32,
#  		     -maxlength=>32}))),
#      Tr(td({-align=>'right'}, "Estimated Cost:"),
#         td(textfield({-name=>'itemcost', -size=>9,
#  		     -maxlength=>9}))),
#      end_table();
    
    print table({-align=>'center', -cellspacing=>5,
		 -cellpadding=>0, -border=>0}, "\n",
		Tr(td({-align=>'center'},submit("Submit")), "\n",
		   td({-align=>'center'},reset("Reset")))), "\n",
    end_form;
    
} # End print_query_form

########## UPDATE THE DATABASE ##########
sub update_database {
# Description: update the database with form input
# Input: validated values and warning message.
# Output: none.

    my %valuepairs = %{shift(@_)};
    my ($dbh, $sth, $rv, $rc);
    
    $dbh = open_database("/home/httpd/.jobDBAccess");

    # Find out the email of the person responsible for specified
    # job category if any.  
    $sth = $dbh->prepare(qq{SELECT email, fullname
				FROM assignlist, category
				    WHERE category.name = assignlist.name
					AND category.id = ?});
    $sth->execute($valuepairs{"category"}) or die "execute: $sth->errstr";
    @resp = $sth->fetchrow_array;
    $sth->finish;

    $sth = $dbh->prepare(qq{insert into jobRequest values
				(sysdate,?,?,?,?,?,?,?,?)});

    $name = $valuepairs{"firstname"} . " " . $valuepairs{"lastname"};
    $sth->bind_param(1,$name);
    $sth->bind_param(2,$valuepairs{"room"});
    $sth->bind_param(3,$valuepairs{"phone"});
    $sth->bind_param(4,$valuepairs{"email"});
    $sth->bind_param(5,$valuepairs{"machine_type"});
    $sth->bind_param(6,$valuepairs{"OS"});
    $sth->bind_param(7,$valuepairs{"building"});
    $sth->bind_param(8,$valuepairs{"description"});
    $rv = $sth->execute or die "executing:  $sth->errstr";
    $sth->finish;
    
    $rc = $dbh->commit || die $dbh->errstr;
    
    # The DB has been updated, we can warn the right person
    # that a new request must be processed.
    $recipient = 'kindness@email.sjsu.edu';
    $subject = "New Request from : " . $name;
    $postinput = "Request author : " . $name . "\n";
    if ($valuepairs{"email"}) {
	$postinput .= "Email : " . $valuepairs{"email"} . "\n";
    }
    if ($valuepairs{"phone"}) {
	$postinput .= "Phone : (408) 924-" . $valuepairs{"phone"} . "\n";
    }
    $postinput .= "Building : " . $valuepairs{"building"} . "\tRoom : " . $valuepairs{"room"} . "\nDescription of Problem : " . $valuepairs{"description"};

    send_mail($recipient,"ECS Job Tracking", $subject, $postinput);

    # Get ID number from the database by getting the data and time the
    # request was received. This is not a robust method of determining
    # the primary key but changing this to use sequences will require
    # major changes to the program.
    $sth = $dbh->prepare(qq{SELECT TO_CHAR(datereceived, 'MMDDYYYYHH24MISS')
				FROM jobrequest WHERE jobdescription = ?
				ORDER BY datereceived DESC});
    $sth->execute($valuepairs{"description"}) or die "execute: $sth->errstr";
    @id = $sth->fetchrow_array;
    $sth->finish;

    # Update job request with category field
    $sth = $dbh->prepare(qq{UPDATE jobmanage SET catagory = ?
				WHERE datereceived = TO_DATE(?, 'MMDDYYYYHH24MISS')});
    $sth->execute($valuepairs{"category"}, $id[0]) or die "execute: $sth->errstr";
    $sth->finish;
    
    # If the user gave an e-mail address, we confirm
    # the processing of the request.
    unless ($valuepairs{"email"} eq "None") {
	$recipient = $valuepairs{"email"};
	$subject = "Your Request is Being Processed";
	$content = "\nYour request is important to us and we will process it as quickly as possible.\n" .
	    "The ID number of your request is $id[0].\n" .
	    "The ID is generated based on the date and time your request arrived at our system.\n\n" .
	    "Thank you for using the ECS Job Tracking System.\n\n" .
	    "Sincerely,\n\nThe ECS Staff";

	send_mail($recipient,"ECS Job Tracking", $subject, $content);
    }

    # If a default responder for specified category exists then
    # send a warning email to them.
    if (defined @resp) {
	$recipient = $resp[0];
	$subject = "Job Request Alert";
	$content = "\nHello $resp[1],\n\n" .
	    "A new job request was entered may be of interest to you.\n" .
	    "The ID number of this request is $id[0].\n\n" .
	    "The job description was:\n" .
	    "-"x60 . "\n" . $valuepairs{"description"} . "\n" . "-"x60 . "\n\n" .
	    "This is only an advisory email and no action is expected of you.\n\n" .
	    "Sincerely,\nThe JobTrack System";

	send_mail($recipient,"ECS Job Tracking", $subject, $content);
    }
    
    # Then we can display the confirmation screen
    print h3({-align=>'center'}, "Job Request Confirmation"),
    "Your request has been accepted and will be processed ",
    "as soon as possible. You will receive a confirmation ",
    "email. Thank you for using the ECS Job Tracking System.",
    "Please make another choice from the menu to the left.";

} # End update_database
