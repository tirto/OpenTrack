#!/usr/bin/perl -w

use GD;
use GD::Graph::pie;
use CGI qw(:standard);

my @data = ( ["1st", "2nd", "3rd", "4th"],
	  [10, 20, 50, 80] );

my $graph = GD::Graph::pie->new(400, 300);
$graph->set(x_label => 'X Label',
	    y_label => 'Y Label',
	    title => 'Some Title',
	    y_tick_number => 4,
	    y_label_skip => 2);

my $format = $graph->export_format;
print header("image/$format");
binmode STDOUT;
print $graph->plot(\@data)->$format();
