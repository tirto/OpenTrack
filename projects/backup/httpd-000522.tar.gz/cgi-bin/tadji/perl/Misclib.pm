package Misclib;

use Exporter;
@ISA = qw(Exporter);
@EXPORT = qw(print_query_form open_database format_sid
	     format_name format_phone format_term
	     normalize_course_name encode_url
	     normalize_student_id normalize_student_name
	     generate_password save_password send_mail
	     check_email_address append_log format_prereq
	     check_term);

use DBI;
use CGI qw/:standard :html3 escape/;
use Fcntl qw(:DEFAULT :flock);

############################################################

# Project: CMPE Student Advising
# File:    Misclib.pl
# By:      Prasanth Kumar
# Date:    Jul 14, 2000

# Description:
#  Library of misc utility functions.

# ChangeLog:
# 07/14/2000 Prasanth Kumar
# - initial version
# 07/17/2000 Prasanth Kumar
# - add functions format_sid, format_name
# 07/18/2000 Prasanth Kumar
# - add functions format_phone, format_term
# 07/19/2000 Prasanth Kumar
# - add functions normalize_course_name, encode_url
# 07/20/2000 Prasanth Kumar
# - add function normalize_student_name
# 07/21/2000 Prasanth Kumar
# - fix regex in normalize_course_name to a letter
#   between course number and section number
# 07/24/2000 Prasanth Kumar
# - add function generate_password
# 07/25/2000 Prasanth Kumar
# - add function check_email_address, send_mail
# 07/28/2000 Prasanth Kumar
# - modify format_term to return 'None' for blank terms
# 08/03/2000 Prasanth Kumar
# - add function format_prereq

############################################################
# GLOBAL VARIABLES

BEGIN
{
	$ENV{ORACLE_HOME} = "/projects/oracle";
	$ENV{ORACLE_SID} = "rdb1";
}

my @semester_list = ( "Online", "Winter", "Spring", "Summer", "Fall",
		      "Spring Special", "Fall Special", "Ext. #1",
		      "Ext. #2", "Ext. #3");

########## PRINT THE QUERY FORM ##########
sub print_query_form {
    
    print h3({-align=>'center'}, "Laboratory Usage Query"),
    "<center>Please Select a Laboratory Room Number</center><br>";
    
    print start_form;
    print table({-align=>'center', -border=>0, -cellspacing=>10},
		Tr(td({-align=>'right'}, "Laboratory Room Number:"),
		   td(textfield(-name=>'roomnumber_id', -default=>'',
				-size=>5, -maxlength=>5)),
		   td(submit(-name=>'search', -label=>'Proceed'))));
    print end_form;
    
} # End print_query_form

############################################################
# OPEN A DATABASE

sub open_database($) {
# Description: get database login and password from file and open
#   a database. file consists of two lines of account and password.
# Input: access file
# Output: handle to database    

    my $access_file = shift;
    
    open(FILE, $access_file) or
	die "no password file $access_file";

    chop($DBlogin = <FILE>);
    chop($DBpassword = <FILE>);
    $dbh = DBI->connect('DBI:Oracle:', $DBlogin, $DBpassword,
			{PrintError=>1, RaiseError=>1, AutoCommit=>1}) or
			    die "connecting : $DBI::errstr";

    close(FILE);
    return $dbh;
    
} # open_database

############################################################
# FORMAT A STUDENT ID

sub format_sid($) {
# Description: reformats a 9 digit SID to appear as ###-##-####
# Input: sid string
# Output: formatted sid string
    
    my $sid = shift;

    $sid =~ s/^(\d{3})(\d{2})(\d{4})$/$1-$2-$3/;
    return $sid;

} # format_sid

############################################################
# FORMAT A STUDENT NAME

sub format_name($) {
# Description: reformat the student name to uppercase/lowercase
# Input: name string
# Output: formatted name string

    my $name = shift;
    
    $name =~ s/(\w+)/\L\u$1/g;
    return $name;

} # format_name

############################################################
# FORMAT A PHONE NUMBER

sub format_phone($) {
# Description: Reformat the 10 digit phone number to (###)###-####
# Input: phone string
# Output: formatted phone string
    
    my $phone = shift;
    $phone =~ s/^(\d{3})(\d{3})(\d{4})$/($1)$2-$3/;
    return $phone;
    
} # format_phone

############################################################
# FORMAT A COURSE TERM

sub format_term($) {
# Description: Reformat the term code into a readable string.
#    A term consists of 2 digits of the year and 1 digit semester code.
# Input: term string
# Output: formatted term string

    my $term = shift;

    # ignore blank terms
    return 'None' if ($term eq '');
    
    my $year = substr($term,0,2);
    my $semester = substr($term,2,1);

    # convert a two digit year to 4 digit years
    if ($year > 38) {
	$year += 1900;
    } else {
	$year += 2000;
    }

    # convert semester digit to full name and emit
    return "$semester_list[$semester] $year";

} # format_term

############################################################
# NORMALIZE A COURSE NAME

sub normalize_course_name($) {
# Description: Reformat a course name into standard format
#   of 4 letter department, 4 letter course number and
#   4 letter section. Return a blank string if it does not
#   form a valid course name.    
# Input: course name string
# Output: formatted course name string

    my $course_name = uc shift;

    if ($course_name =~ /^([A-Z]{1,4})\s*(\d{1,3})([A-Z]?|\s)(\d{1,2})\s*$/) {
	my $dept_name = $1;
	my $course_number = $2;
	my $course_letter = $3;
	my $course_section = $4;
	
	return sprintf("%-4s%3.3d%1s%2.2d", $dept_name,
		       $course_number, $course_letter, $course_section);
    } else {
	return '';
    }

} # normalize_course_name

############################################################
# NORMALIZE A STUDENT ID

sub normalize_student_id($) {
# Description: Reformat a student ID into standard format
#   of 9 numbers. Will accept inputs with dashes.
#   Return a blank string if it does not form a valid
#   student ID.
# Input: student id string
# Output: formatted student id string

    my $student_id = shift;

    if ($student_id =~ /^(\d{3})-?(\d{2})-?(\d{4})\s*$/) {
	return sprintf("%3.3d%2.2d%4.4d", $1, $2, $3);
    } else {
	return '';
    }

} # normalize_student_id

############################################################
# NORMALIZE A STUDENT ID

sub normalize_student_name($) {
# Description: Reformat a student name into standard format
#   of capital letters (and dashes commas or spaces).
#   Return a blank string if it does not form a valid
#   student name.
# Input: student name string
# Output: formatted student name string

    my $student_name = uc shift;

    if ($student_name =~ /^[-,A-Z\s]+$/) {
	return $student_name;
    } else {
	return '';
    }

} # normalize_student_name

############################################################
# CHECK A EMAIL ADDRESS

sub check_email_address($) {
# Description: Checks for an email address to be well
#   formed as 'abc@def.edu'. Return a blank string if
#   it does not form a valid
# Input: email address string
# Output: formatted email address string

    my $email_address = lc shift;

    if ($email_address =~ /^[a-z0-9_-]+@[a-z0-9_.-]+$/) {
	return $email_address;
    } else {
	return '';
    }

} # check_email_address

############################################################
# ENCODE AN URL

sub encode_url($%) {
# Description: Forms a properly encoded url w/ parameters
# Input: base string and args hash
# Output: encoded url

    my $url_base = shift;
    my %url_args = @_;
    my $key;
    
    if (%url_args) {
	$url_base .= '?';
	foreach $key (keys %url_args) {
	    $url_base .= escape($key) . '=' . escape($url_args{$key}) . '&';
	}
	chop($url_base);
    }
    return $url_base;
    
} # encode_url

############################################################
# GENERATE A PASSWORD

sub generate_password($) {
# Description: Produces a random password composed of
#   letters and numbers.
# Input: password length
# Output: password string

    my $pass_length = shift;

    # seed random number generator
    srand;

    # skip characters I, O, 1, 0 because they can
    # be confusing for people to type
    my @pass_chars = ("A".."H", "J".."N", "P".."Z", 2..9);
    return join("", @pass_chars[map {rand @pass_chars} (1..$pass_length)]);
    
} # generate_password

############################################################
# SAVE A PASSWORD

sub save_password($$$) {
# Description: saves a username and password to a htaccess file
# Input: password filename, username and password string
# Output: returns error code if update failed

    my $passfile = shift;
    my $username = shift;
    my $password = shift;

    # safety check for alphanumeric usename and password
    return 'invalid username' if $username !~ /^\w+$/;
    return 'invalid password' if $password !~ /^\w+$/;

    # trap any failures of password updates
    eval {
	system("/usr/bin/htpasswd", "-b", $passfile, $username, $password);
    };
    return 'update failure' if $@;

    # ADD LOGGING CAPABILITES HERE?
    
    passwd updates
    return '';
    
} # save_password

############################################################
sub send_mail($$$@) {
# Description: a simple e-mail routine which makes use of the sendmail
#   executable.
# Input: to address, from address, mail subject, mail body
# Output: none
    
    my $to_address = shift(@_);
    my $from_address = shift(@_);
    my $mail_subject = shift(@_);
    my @mail_body = @_;

    my $mailprog = '/usr/lib/sendmail';
    open (MAIL, "|$mailprog -t") || die "Can't open $mailprog!\n";

    print MAIL "To: " . $to_address . "\n";
    print MAIL "From: " . $from_address . "\n";
    print MAIL "Subject: " . $mail_subject . "\n\n" ;
    print MAIL @mail_body;

    close(MAIL);

} # send_mail

############################################################
sub append_log($$) {
# Description: appends a line of text to a log file along with
#   the current time    
# Input: filename and text
# Output: none
    
    my $log_file = shift(@_);
    my $log_text = shift(@_);

    # use file locking to prevent simultaneous writes
    eval {open(LOGFILE, ">> $log_file");
	  flock(LOGFILE, 2);
	  print LOGFILE scalar localtime, " ", $log_text, "\n";
	  close(MAIL);
      };
    
    die "can't write to logfile $log_file" if $@;
    
} # append_log

############################################################
# FORMAT A PREREQ

sub format_prereq($) {
# Description: reformat the prereq field to replace newlines
#   with <br> for use in html.
# Input: prereq string
# Output: formatted name string

    my $prereq = shift;

    chomp($prereq);
    $prereq =~ s/(.+?)\n/$1<br>/g;
    return $prereq;

} # format_prereq

############################################################
# CHECK A CLASS TERM

sub check_term($) {
# Description: Checks for a valid class term to be well
#   formed as 3 digits. Return a blank string if
#   it does not form a valid
# Input: class term string
# Output: validated class term string

    my $class_term = shift;

    if ($class_term =~ /^\d{3}$/) {
	return $class_term;
    } else {
	return '';
    }

} # check_term

1;
