create table mylabsoftware (
       building		   varchar2(5) NOT NULL,
       roomnumber	   varchar2(6) NOT NULL,
       software		   varchar2(32) NOT NULL,
       copies		   number(3) NOT NULL,
       comments		   varchar2(255),
       primary key (building, roomnumber, software));
