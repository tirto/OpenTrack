#!/usr/bin/perl -w

use DBI;
use CGI qw/:standard :html3 escape/;
use 5.004;

#GENERAL CONFIGURATION PARAMETERS

BEGIN 

{
    $ENV{ORACLE_HOME} = "/projects/oracle";
    $ENV{ORACLE_SID} = "rdb1";
}

$DBlogin = "girish";
$DBpassword = "oracle8i";
$term = '014';
@weekDays=("M","T","W","R","F","S","U");
@dayNames=("Monday","Tuesday","Wednesday","Thursday",
	   "Friday","Saturday","Sunday");

print header(),
    start_html(-title=>'College of Engineering Scheduling System',-BGCOLOR=>'white'),
    h1({-align=>'center'},"College of Engineering Scheduling System"),
    p({-align=>'center'},img{-src=>"http://www.engr.sjsu.edu/images/jpgs/sjsu-coe.jpg"});

if (param('term')) {
    $term = param('term');
}

    print h2({-align=>'center'},"Term: ",$term);

    $dbh = DBI->connect('DBI:Oracle:', $DBlogin, $DBpassword, {PrintError=>1,RaiseError=>1})
    or die "connecting :   $DBI::errstr";

for ($weekIndex = 0; $weekIndex < 1; $weekIndex++) {
     
    print h2({-align=>'center'},$dayNames[$weekIndex]," - Unscheduled courses:");
    print "<TABLE ALIGN=CENTER WIDTH=90% BORDER=1>";
    print Tr({-bgcolor=>"#11EE88"},#td("Select"),
	     td("Department"),td("Codenumber"),td("Section"),
	     td("Starts"),td("Ends"),td("MaxEnrol"), td("Days"));

    $sth = $dbh->prepare(qq{
    SELECT co.department, co.codeNumber, co.section,
    cl.counter, cl.startTime, cl.stopTime,
    co.maxEnrollment, cl.days
	FROM course co, classmeetingx cl
	WHERE co.term = '$term'
	AND co.term = cl.term
	AND co.department = cl.department
	AND co.codenumber = cl.codenumber
	AND co.section = cl.section
	AND cl.days LIKE '%$weekDays[$weekIndex]%'
	AND (co.activity = 'LEC' OR co.activity = 'SEM')
	AND (cl.building = 'NA' OR cl.roomnumber = 'NA')
	ORDER BY cl.startTime, co.maxEnrollment DESC});
    $sth->execute or die "executing: $sth->errstr";

    
    while (@row = $sth->fetchrow_array) {
	my ($dept,$codenumber,$section,$counter,$strt,$stp,$maxEnroll,$days) = @row;
        $url =  encode_url("http://ecs-staff14.engr.sjsu.edu/cgi-bin/tadji/editX.pl",
			 bldg=>"ENG",
			 room=>"NA",
			 dept=>$dept,
			 codenumber=>$codenumber,
			 section=>$section);
	print Tr(#td(a({-href=>$url},"edit")),
		 td($row[0]),
		 td(a({-href=>$url},$row[1])),
		 td($row[2]),
		 td($row[4]),
		 td($row[5]),
		 td($row[6]),
		 td($row[7]));
    }

    print "</TABLE>";

    $sth = $dbh->prepare(qq{SELECT co.department, co.codeNumber, co.section,
			    cl.counter, co.maxEnrollment, cl.startTime,
			    cl.stopTime, cl.days, cl.building, cl.roomNumber
				FROM course co, classmeetingx cl
				    WHERE co.term = '$term'
					AND co.term = cl.term
					AND co.department = cl.department
					AND co.codenumber = cl.codenumber
					AND co.section = cl.section
					AND cl.days LIKE '%$weekDays[$weekIndex]%'
					AND cl.days NOT LIKE '%TBA%'
					AND cl.roomnumber NOT LIKE 'NA'    
					AND co.activity <> 'LAB'
					    ORDER BY cl.startTime,
					    co.maxEnrollment DESC});
    $sth->execute or die "executing: $sth->errstr";

    print h2({-align=>'center'},$dayNames[$weekIndex]," - All courses:");
    print "<TABLE ALIGN=CENTER WIDTH=90% BORDER=1>";
    print Tr({-bgcolor=>"#9999FF"}, td("Department"), td("Codenumber"),
	     td("Section"), td("Starts"), td("Ends"),
	     td("MaxEnrol"), td("Days"), td("Building"), td("RoomNb"));

    while (@row = $sth->fetchrow_array) {
	print Tr(td($row[0]),td($row[1]),td($row[2]),
		 td($row[5]),td($row[6]),td($row[4]),td($row[7]),
		 td($row[8]),td($row[9]));
    }

    print "</TABLE>";

} #end of weekIndex loop
 
print end_html;

############################################################
sub encode_url($%) {
# Description: Forms a properly encoded url w/ parameters
# Input: base string and args hash
# Output: encoded url

    my $url_base = shift;
    my %url_args = @_;
    my $key;

    if (%url_args) {
        $url_base .= '?';
        foreach $key (keys %url_args) {
	    $url_base .= escape($key) . '=' . escape($url_args{$key}) . '&';
        }
        chop($url_base);
    }
    return $url_base;

} # encode_url
