DESCRIBE wh_bio_demo;
DESCRIBE wh_term;

TRUNCATE TABLE wh_bio_demo;
TRUNCATE TABLE wh_term;

DROP TABLE wh_bio_demo;
DROP TABLE wh_term;

CREATE TABLE wh_bio_demo (
       bio_sid		 VARCHAR2(09)	NOT NULL,
       bio_name		 VARCHAR2(32)	NOT NULL,
       CONSTRAINT pk_wh_bio_demo
		  PRIMARY KEY (bio_sid)
		  USING INDEX
		  TABLESPACE wh_bio_i
)

CREATE TABLE wh_term (
       trm_sid		VARCHAR2(09)	NOT NULL,
       trm_term		VARCHAR2(03)	NOT NULL,
       trm_major_1	VARCHAR2(04)	NOT NULL,
       trm_curr_x_hrs	NUMBER(04, 02)	NOT NULL,
       trm_curr_gpa	NUMBER(03, 02)	NOT NULL,
       CONSTRAINT pk_wh_term
		  PRIMARY KEY (trm_sid, trm_term)
		  USING INDEX
		  TABLESPACE wh_term_i
)

CREATE TABLE wh_crswork (
       cwk_sid		VARCHAR2(09)	NOT NULL,
       cwk_term		VARCHAR2(03)	NOT NULL,
       cwk_sp_course	VARCHAR2(11)	NOT NULL,
       CONSTRAINT pk_wh_crswork
		  PRIMARY KEY (cwk_sid, cwk_term, cwk_sp_course)
		  USING INDEX
		  TABLESPACE wh_crswork_i
)

       