select term, department, codenumber, section, counter, count_total, days, starttime, stoptime from classmeeting where term = '994'
