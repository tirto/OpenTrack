#! /usr/bin/perl -w

use CGI qw/:standard/;
print header,
	start_html('hello world'),
	h1('hello world'),
	end_html;