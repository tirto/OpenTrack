package datelib;

BEGIN {
    use Exporter;
    @ISA = qw(Exporter);
    @EXPORT = qw(this_year this_month this_day leap_year
		 last_day valid_date date_string
		 $the_days $the_months $the_years);
}

# Project: Job Tracking System
# File:    datelib.pl
# By:      Prasanth Kumar
# Date:    Dec 13, 2000

# Description:
# Library of date subroutines

# ChangeLog:
# 12/13/2000 Prasanth Kumar
# - start file
# 12/19/2000 Prasanth Kumar
# - export the_date, the_month and the_year lists

# VARIABLES SECTION

$the_days = [ 1..31 ];
$the_months = { 1=>'Jan', 2=>'Feb', 3=>'Mar', 4=>'Apr', 5=>'May',
		6=>'Jun', 7=>'Jul', 8=>'Aug', 9=>'Sep', 10=>'Oct',
		11=>'Nov', 12=>'Dec' };
$the_years = [ (this_year()-1)..(this_year()+4) ];

# SUBROUTINE SECTION

########## CALCULATE THE CURRENT YEAR ##########
sub this_year() {

    my ($year) = (localtime)[5]+1900;
    return $year;
}

########## CALCULATE THE CURRENT MONTH ##########
sub this_month() {

    my ($month) = (localtime)[4] + 1;
    return $month;
}

########## CALCULATE THE CURRENT DAY ##########
sub this_day() {

    my ($day) = (localtime)[3];
    return $day;
}

########## IS A LEAP YEAR ##########
sub leap_year($) {

    my $year = shift;

    if (($year % 4 == 0) && ($year % 100 != 0)) {
	# leap year since divisible by 4 but not 100
	return 1;
    } elsif (($year % 4 == 0) && ($year % 100 == 0) && ($year % 400 == 0)) {
	# leap year since divisible by 4, 100 and 400
	return 1;
    } else {
	# all other cases are not a leap year
	return 0;
    }
}

########## LAST DAY OF MONTH ##########
sub last_day($$) {

    my ($month, $year) = @_;
    my @days_in_month = (31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);

    if (($month == 2) && (leap_year($year))) {
	# a february and leap year
	return $days_in_month[$month - 1] + 1;
    } else {
	# all other months
	return $days_in_month[$month - 1];
    }
}

########## VALID DATE ##########
sub valid_date($$$) {

    my ($month, $day, $year) = @_;
    
    # is the year within range?
    if (($year < 1900) || ($year > 2038)) {
	$year = this_year();
    }

    # is the month within range?
    if (($month < 1) || ($month > 12)) {
	$month = this_month();
    }

    # is the day within range?
    if (($day < 1) || ($month > 31)) {
	$day = this_day();
    }

    # is the day within range for the month?
    if ($day > last_day($month, $year)) {
	$day = 1;
	$month = $month + 1;
	if ($month > 12) {
	    $month = 1;
	    $year = $year + 1;
	    if ($year > 2038) {
		$year = 2038;
	    }
	}
    }
    return ($month, $day, $year);
}

########## CONVERT DATE TO STRING ##########
sub date_string($$$) {

    my $date = sprintf("%2.2d-%2.2d-%4.4d", @_);
    return $date;
}

1;
