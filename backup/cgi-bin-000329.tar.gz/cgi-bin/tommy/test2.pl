#! usr/bin/perl -w

use DBI;

# Project: Classroom Scheduler
# File: extractdata.pl
# By: Phuoc Diec
# Date: August 26, 1999
# Description:
# Retrieve data from data warehouse and populate the locate database.

$sid = '615662794';

BEGIN 
{
  $ENV{ORACLE_HOME} = "/projects/oracle";
  $ENV{ORACLE_SID} = "ware";
}

$dbh = DBI->connect('DBI:Oracle:', 'kindness1/b4u4getit@ware', '', {PrintError=>1, RaiseError=>1}) or die "connecting: $DBI::errsrtr";

$sth1 = $dbh->prepare(qq{SELECT *
                         FROM warehouse.wh_bio_demo
			     where warehouse.wh_bio_demo.bio_sid = '$sid'
			});
$sth1->execute or die "Executing: $sth1->errstr";

BEGIN 
{
  $ENV{ORACLE_HOME} = "/projects/oracle";
  $ENV{ORACLE_SID} = "rdb1";
}

while ($row_ref = $sth1->fetchrow_hashref) {

    foreach $key (sort keys %$row_ref) {

	print "\n$key: $row_ref->{$key}\n";

    }

}

$sth1->finish;

$dbh->disconnect;
