#!/usr/bin/perl 

#Still to be done:
#1) The case of course spanning on several days hasn't been considered yet
#2) We could try and overload some rooms to see if they can receive a course
#3) Harder, some fine tuning could still be done, like there would be some overlapping on one room
#   while another that was smaller but sufficient could have been used instead
#   The idea woul be not to take the first room that has enough space but the smallest of those
#   Can it happen? That' s the question since courses are also in descending order
use DBI;
use CGI qw/:standard :html3/;
use 5.004;

#GENERAL CONFIGURATION PARAMETERS

BEGIN 

{
    $ENV{ORACLE_HOME} = "/projects/oracle";
    $ENV{ORACLE_SID} = "rdb1";
}

$DBlogin = "girish";
$DBpassword = "oracle8i";
$term = '994';
@weekDays=("M","T","W","R","F","S","U");

print header(),
      start_html(-title=>'College Of Engineering Scheduling System',-BGCOLOR=>'white'),
      h1({-align=>center},"College Of Engineering Scheduling System"),
      p({-align=>center},img{-src=>"http://www.engr.sjsu.edu/images/jpgs/sjsu-coe.jpg"});


  $dbh = DBI->connect('DBI:Oracle:', $DBlogin, $DBpassword, {PrintError=>1,RaiseError=>1}) or die "connecting :   $DBI::errsrtr";
  my $page  = param("page");


  $sth = $dbh->prepare(qq{
	SELECT building, roomNumber, capacity
	FROM room
	WHERE category = 'classroom'
	ORDER BY capacity DESC
	});
  $sth->execute or die "executing: $sth->errstr";

  $roomIndex = 0;
  while (@row = $sth->fetchrow_array) {
    $room[$roomIndex] = $row[0];				#building
    $room[$roomIndex+1] = $row[1];				#roomNumber
    $room[$roomIndex+2] = $row[2];				#capacity
    $room[$roomindex+3] = int($row[2] * 1.05);	#overloaded capacity
    $room[$roomIndex+4] = '';					#string to store array of bits. 5h20 - 24h00 = 224 five-minute slots
    vec($room[$roomIndex+4], 0, 32) = 0;		#therefore we create a 224-entry array of bits
    vec($room[$roomIndex+4], 1, 32) = 0;		#this means 7 entries of 32 bits
    vec($room[$roomIndex+4], 2, 32) = 0;		#we must initialize the array at first
    vec($room[$roomIndex+4], 3, 32) = 0;		#by putting '0' in every slot
    vec($room[$roomIndex+4], 4, 32) = 0;		#which means that the slot is free
    vec($room[$roomIndex+4], 5, 32) = 0;		#when a course occupies the slot
    vec($room[$roomIndex+4], 6, 32) = 0;		#it will take a value of '1'
    $room[$roomIndex+5] = '';					#index+4 = Monday
    vec($room[$roomIndex+5], 0, 32) = 0;		#index+5 = Tuesday
    vec($room[$roomIndex+5], 1, 32) = 0;		#index+6 = Wednesday
    vec($room[$roomIndex+5], 2, 32) = 0;		#index+7 = thuRsday
    vec($room[$roomIndex+5], 3, 32) = 0;		#index+8 = Friday
    vec($room[$roomIndex+5], 4, 32) = 0;		#index+9 = Saturday
    vec($room[$roomIndex+5], 5, 32) = 0;		#index+10 = sUnday
    vec($room[$roomIndex+5], 6, 32) = 0;
    $room[$roomIndex+6] = '';
    vec($room[$roomIndex+6], 0, 32) = 0;
    vec($room[$roomIndex+6], 1, 32) = 0;
    vec($room[$roomIndex+6], 2, 32) = 0;
    vec($room[$roomIndex+6], 3, 32) = 0;
    vec($room[$roomIndex+6], 4, 32) = 0;
    vec($room[$roomIndex+6], 5, 32) = 0;
    vec($room[$roomIndex+6], 6, 32) = 0;
    $room[$roomIndex+7] = '';
    vec($room[$roomIndex+7], 0, 32) = 0;
    vec($room[$roomIndex+7], 1, 32) = 0;
    vec($room[$roomIndex+7], 2, 32) = 0;
    vec($room[$roomIndex+7], 3, 32) = 0;
    vec($room[$roomIndex+7], 4, 32) = 0;
    vec($room[$roomIndex+7], 5, 32) = 0;
    vec($room[$roomIndex+7], 6, 32) = 0;
    $room[$roomIndex+8] = '';
    vec($room[$roomIndex+8], 0, 32) = 0;
    vec($room[$roomIndex+8], 1, 32) = 0;
    vec($room[$roomIndex+8], 2, 32) = 0;
    vec($room[$roomIndex+8], 3, 32) = 0;
    vec($room[$roomIndex+8], 4, 32) = 0;
    vec($room[$roomIndex+8], 5, 32) = 0;
    vec($room[$roomIndex+8], 6, 32) = 0;
    $room[$roomIndex+9] = '';
    vec($room[$roomIndex+9], 0, 32) = 0;
    vec($room[$roomIndex+9], 1, 32) = 0;
    vec($room[$roomIndex+9], 2, 32) = 0;
    vec($room[$roomIndex+9], 3, 32) = 0;
    vec($room[$roomIndex+9], 4, 32) = 0;
    vec($room[$roomIndex+9], 5, 32) = 0;
    vec($room[$roomIndex+9], 6, 32) = 0;
    $room[$roomIndex+10] = '';
    vec($room[$roomIndex+10], 0, 32) = 0;
    vec($room[$roomIndex+10], 1, 32) = 0;
    vec($room[$roomIndex+10], 2, 32) = 0;
    vec($room[$roomIndex+10], 3, 32) = 0;
    vec($room[$roomIndex+10], 4, 32) = 0;
    vec($room[$roomIndex+10], 5, 32) = 0;
    vec($room[$roomIndex+10], 6, 32) = 0;
      
    $roomIndex += 11;
  }
  $sth->finish;

  $nbRooms = $roomIndex;
  #Each day is considered seperately        
  for ($weekIndex = 0; $weekIndex <7; $weekIndex++) {
    $sth = $dbh->prepare(qq{
    SELECT co.department, co.codeNumber, co.section, cl.counter, co.maxEnrollment, cl.startTime, cl.stopTime, cl.days, LENGTH(rtrim(cl.days)), cl.building, cl.roomNumber
	FROM course co, classmeeting cl
	WHERE co.term = '$term'
	AND co.term = cl.term
	AND co.department = cl.department
	AND co.codenumber = cl.codenumber
	AND co.section = cl.section
	AND cl.days LIKE '%$weekDays[$weekIndex]%'
	AND co.activity <> 'LAB'
	ORDER BY co.maxEnrollment DESC, cl.startTime, LENGTH(cl.days) DESC
	});

    $sth->execute or die "executing: $sth->errstr";

    $meetingIndex = 0;
    while (@row = $sth->fetchrow_array) {
      if ($row[7] !~ /TBA    / and $row[9] =~ /\W/) {		#If row[9] not empty, the course has already been scheduled
	$meeting[$meetingIndex] = $row[0];			#department
	$meeting[$meetingIndex+1] = $row[1];		#codeNumber
	$meeting[$meetingIndex+2] = $row[2];		#section
	$meeting[$meetingIndex+3] = $row[3];		#counter
	$meeting[$meetingIndex+4] = $row[4];		#maxEnrollment
	$meeting[$meetingIndex+5] = $row[5];		#startTime
	$meeting[$meetingIndex+6] = $row[6];		#stopTime
	$meeting[$meetingIndex+7] = $row[7];		#days concerned
	$meeting[$meetingIndex+8] = $row[8];		#number of days
	$meetingIndex += 11;						#we set room for cl.building and cl.roomNumber
      }
    }
    $sth->finish;
     
    $nbMeetings = $meetingIndex;
    $conflictIndex = 0;
    for ($meetingIndex = 0; $meetingIndex < $nbMeetings; $meetingIndex+=11) {
      @start = unpack("c4",$meeting[$meetingIndex+5]);
      $hours = 10 * ($start[0] - ord('0')) + $start[1] - ord('0');
      $minutes = 10 * ($start[2] - ord('0')) + $start[3] - ord('0');
      $startIndex = ($hours - 6) * 12 + $minutes / 5;

      @finish = unpack("c4",$meeting[$meetingIndex+6]);
      $hours = 10 * ($finish[0] - ord('0')) + $finish[1] - ord('0');
      $minutes = 10 * ($finish[2] - ord('0')) + $finish[3] - ord('0');
      $stopIndex = ($hours - 6) * 12 + $minutes / 5;
      #We check all the rooms to reserve time for the course
      $conflict = 1;
      for ($roomIndex = 0; $roomIndex < $nbRooms; $roomIndex+=11) {
	$isGoodRoom = 1;
	#We check if all slots are free for the period required by the course
	for ($timeSlotIndex = $startIndex; $timeSlotIndex < $stopIndex; $timeSlotIndex++) {
	  if (vec($room[$roomIndex+4+$weekIndex], $timeSlotIndex, 1) == 1) {
	    $isGoodRoom = 0;				#Too bad! one slot has already been used
	    $timeSlotIndex = $stopIndex;	#We jump out of the loop
	  }
	}
	if ($isGoodRoom == 1) {
	  #First, we lock the timeSlots alloted to that course
	  for ($timeSlotIndex = $startIndex; $timeSlotIndex < $stopIndex; $timeSlotIndex++) {

	    vec($room[$roomIndex+4+$weekIndex], $timeSlotIndex, 1) = 1;
	  }
	  $meeting[$meetingIndex+9] = $room[$roomIndex];	#We register the building for the course
	  $meeting[$meetingIndex+10] = $room[$roomIndex+1];	#We register the roomNumber
	  $conflict = 0;									#There is not conflict for that course
	  
	  if ($meeting[$meetingIndex+8] > 1) {				#There are other days for that course
	    #Logic: we try to assignate the same room for the other days
	    #1)it' s possible, good
	    #2)it' s not possible and count_total<3, we create a new counter value and split the days
	    #3)it' s not possible, count_total=3, let' s rollback and find another room
	  }
	  
	  $roomIndex = $nbRooms;							#We finally jump out of the loop
	} #fi isGoodRoom
      } #end of roomIndex loop
      if ($conflict == 1) {
      	$conflicts[$conflictIndex] = $meeting[$meetingIndex];		#Conflicting course department
      	$conflicts[$conflictIndex+1] = $meeting[$meetingIndex+1];	#Conflicting course codenumber
      	$conflicts[$conflictIndex+2] = $meeting[$meetingIndex+2];	#Conflicting course section
      	$conflicts[$conflictIndex+3] = $meeting[$meetingIndex+3];	#Conflicting course counter
      	$conflicts[$conflictIndex+4] = $meeting[$meetingIndex+5];	#start time
      	$conflicts[$conflictIndex+5] = $meeting[$meetingIndex+6];	#stop time
      	$conflicts[$conflictIndex+6] = $meeting[$meetingIndex+4];	#maximum enrollment for course
      	$conflictIndex += 7;
      }
    } #end of meetingIndex loop
     
    print h2({-align=>center},$weekDays[$weekIndex]," - Conflicting courses:");
    print "<TABLE ALIGN=CENTER>";
    print Tr({-bgcolor=>"#11EE88"},td("Department"),td("Codenumber"),td("Section"),td("Counter"),td("Starts"),td("Ends"),td("MaxEnrol"));
    for ($i=0; $i<$conflictIndex; $i+=7) {
      print Tr(td($conflicts[$i]), td($conflicts[$i+1]), td($conflicts[$i+2]), td($conflicts[$i+3]), td($conflicts[$i+4]), td($conflicts[$i+5]), td($conflicts[$i+6]));
    }
    print "</TABLE>";
    
    print h2({-align=>center},$weekDays[$weekIndex]," - All courses:");
    print "<TABLE ALIGN=CENTER>";
    print Tr({-bgcolor=>"#9999FF"}, td("Department"), td("Codenumber"), td("Section"), td("Counter"), td("Starts"), td("Ends"), td("MaxEnrol"), td("Building"), td("RoomNb"));
    for ($i=0; $i<$nbMeetings; $i+=11) {
      print Tr(td($meeting[$i]),td($meeting[$i+1]),td($meeting[$i+2]),td($meeting[$i+3]),td($meeting[$i+5]),td($meeting[$i+6]), td($meeting[$i+4]), td($meeting[$i+9]), td($meeting[$i+10]));
    }
    print "</TABLE>";

  } #end of weekIndex loop
 
print end_html;
