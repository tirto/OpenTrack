update students
       set students.current_credits = students.current_credits + 33
       where students.major = 'Computer Science';
