#!/usr/bin/perl -w

use strict;
use CGI qw(:standard);
use CGI::Carp qw(fatalsToBrowser);
use Misclib;

########### SET UP A PATH TO THE DATABASE ##############
BEGIN {
    $ENV{ORACLE_HOME} = "/projects/oracle";
    $ENV{ORACLE_SID} = "rdb1";
}

my %Features;    	# features table mapping pages to functions
my $Current_Screen;    	# the current screen
my %param;

# Hash of pages and functions.

%Features = (
    'Default'     => \&front_page,
    'Add'         => \&add,
    'Update'      => \&update,
    'Delete'      => \&delete,
    'Cancel'      => \&front_page,
);

$Current_Screen = param(".State") || "Default";
die "No screen for $Current_Screen" unless $Features{$Current_Screen};

# Generate the current page.

standard_header();

while (my($screen_name, $function) = each %Features) {
    $function->($screen_name eq $Current_Screen);
}

standard_footer();
exit;

################################
# header, footer, menu functions
################################

sub standard_header {
    print header(), start_html(-Title => "Laboratory Inventory Update", -BGCOLOR=>"White");
    print start_form(); # start_multipart_form() if file upload
}

sub standard_footer { print end_form(), end_html() }

#############################
# subroutines for each screen
#############################

# The default page.
sub front_page {
    my $active = shift;

    my ($building, $roomnum, $title, $count, $comment) =
      (param("software_building"), param("software_roomnum"), param("software_title"), param("software_count"), param("software_comment"));

    unless ($active) {
        print hidden("software_building") if $building;
        print hidden("software_roomnum") if $roomnum;
        print hidden("software_title") if $title;
        print hidden("software_count") if $count;
        print hidden("software_comment") if $comment;
        return;
    }

    print h1({-align=>'center'}, "Laboratory Inventory Update Page");
    print p({-align=>'center'}, "(*) You must fill in this field");

    print table({-align=>'center', -cellspacing=>2,
	   -cellpadding=>5, -border=>2},
	  Tr(td({-bgcolor=>'#CCEEFF'}, "Building(*)"),
	     td(textfield("software_building")),
	     td({-bgcolor=>'#CCEEFF'},"Room number(*)"),
	     td(textfield("software_roomnum"))),
	  Tr(td({-bgcolor=>'#CCEEFF'},"Software(*)"),
	     td(textfield("software_title")),
	     td({-bgcolor=>'#CCEEFF'},"Number of copies(*)"),
	     td(textfield("software_count"))),
	  Tr(td({-bgcolor=>'#CCEEFF'},"Comment"),
	     td(textarea(-name=>"software_comment",
			 -rows=>5, -columns=>20,
			 -wrap=>'virtual'))));

    print table({-align=>'center', -cellspacing=>5,
		 -cellpadding=>0, -border=>0},
		Tr(td({-align=>'center'},to_page("Update")),
		   td({-align=>'center'},to_page("Delete"))));
}

# Page to add a software from.
sub add {
    my $active = shift;
    return unless ($active);

    print p("You must enter building!\n") unless param("software_building");
    print p("You must enter room number!\n") unless param("software_roomnum");
    print p("You must enter software title!\n") unless param("software_title");
    print p("You must enter number of copies!\n") unless param("software_count");

    unless (param("software_building") && param("software_roomnum") && param("software_title") && param("software_count")) {
	print p(defaults("Go back"));
	return;
    }

    my $dbh = open_database("/home/httpd/.jobDBAccess");
    my $sth1 = $dbh->prepare(qq{insert into mylabsoftware values (?,?,?,?,?)});
    $sth1->execute(param("software_building"),param("software_roomnum"),param("software_title"),param("software_count"),param("software_comment"))
	or die "Executing: $sth1->errstr";

    print h1("Add successful!");
    print p("You have added the following:");
    print add_text();
    print p(defaults("Go back to main menu"));

    $sth1->finish;
    $dbh->disconnect;
}

# Page to update a software from.
sub update {
    my $active = shift;
    return unless ($active);

    my ($building, $roomnum, $title, $count, $comment) =
      (param("software_building"), param("software_roomnum"), param("software_title"), param("software_count"), param("software_comment"));

    my @fields = qw(software_building software_roomnum software_title software_count software_comment);
    my @values;

    print p("You must enter building!\n") unless $building;
    print p("You must enter room number!\n") unless $roomnum;
    print p("You must enter software title!\n") unless $title;
    print p("You must enter number of copies!\n") unless $count;

    unless ($building && $roomnum && $title && $count) {
	print p(defaults("Go back"));
	return;
    }

    print h1({-align=>'center'}, "Laboratory Inventory Confirmation");
    print p({-align=>'center'}, "(*) You must fill in this field");

    print table({-align=>'center', -cellspacing=>2,
	   -cellpadding=>5, -border=>2},
	  Tr(td({-bgcolor=>'#CCEEFF'}, "Building(*)"),
	     td(param("software_building")),
	     td({-bgcolor=>'#CCEEFF'},"Room number(*)"),
	     td(param("software_roomnum"))),
	  Tr(td({-bgcolor=>'#CCEEFF'},"Software(*)"),
	     td(param("software_title")),
	     td({-bgcolor=>'#CCEEFF'},"Number of copies(*)"),
	     td(param("software_count"))),
	  Tr(td({-bgcolor=>'#CCEEFF'},"Comment"),
	     td(param("software_comment"))));

    print p(hidden("software_building"));
    print p(hidden("software_roomnum"));
    print p(hidden("software_title"));
    print p(hidden("software_count"));
    print p(hidden("software_comment"));

    my $dbh = open_database("/home/httpd/.jobDBAccess");
    $dbh->trace(1, '/tmp/trace.txt');
    my $sth1 = $dbh->prepare(qq{update mylabsoftware set building=?, roomnumber=?, software=?,
				copies=?, comments=? where building='$building' and roomnumber='$roomnum' and software='$title'});
    $sth1->execute($building,$roomnum,$title,$count,$comment) or die "Executing: $sth1->errstr";

    print h1("Update successful!");
    print p("You have modified the following:");
    print add_text();
    print p(defaults("Go back to main menu"));

    $sth1->finish;
    $dbh->disconnect;
}

# Page to delete a software from.
sub delete {
    my $active = shift;
    return unless ($active);

    print p("You must enter building!\n") unless param("software_building");
    print p("You must enter room number!\n") unless param("software_roomnum");
    print p("You must enter software title!\n") unless param("software_title");

    unless (param("software_building") && param("software_roomnum") && param("software_title")) {
	print p(defaults("Go back"));
	return;
    }

    my $dbh = open_database("/home/httpd/.jobDBAccess");
    my $sth1 = $dbh->prepare(qq{delete from mylabsoftware where building=? and roomnumber=?
				and software=?});
    $sth1->execute(param("software_building"),param("software_roomnum"),param("software_title"))
	or die "Executing: $sth1->errstr";

    print h1("Delete successful!");
    print p("You have deleted the following:");
    print add_text();
    print p(defaults("Go back to main menu"));

    $sth1->finish;
    $dbh->disconnect;
}

# Returns HTML for the current action
sub add_text {
    my $html = '';

    $html .= p("Software title: ", param("software_title"));
    $html .= p("Building: ", param("software_building"));
    $html .= p("Room number: ",  param("software_roomnum"));
    $html .= p("Number of copies: ", param("software_count"));
    $html .= p("Comments: ", param("software_comment"));

    return $html;
}

sub to_page { submit(-NAME => ".State", -VALUE => shift) }
