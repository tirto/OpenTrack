<html>
<head>
<title>PHP Test</title>
</head>
<body>
<?php echo "Hello World<P>"; ?>
</body>
</html>
