<?php

/*
 * Schedule_proj.php
 *
 * This program purpose is to perfom automated schedule checking and
 * to report conflicting courses
 * 
 * - It gets data from classmeeting and copies it to the schedule_proj table
 * - more to come
 *
 * @version 1.0		09/13/00
 * @author  Tirto Adji
 */

?>

<!-- HTML HEADER and image -->
<html>
<head><title>COE Scheduling system</title></head>
<body bgcolor=ffffff>
<center>
<table cellpadding=2 cellspacing=4>
  <tr>
     <td>
       <center>
	 <img src="http://www.engr.sjsu.edu/images/jpgs/sjsu-coe.jpg">
       </center>
     </td>
  </tr>
  <tr>
     <center>
       <h1>College of Engineering Scheduling System</h1>
     </center>
  </tr>
</table>
</center>
<!-- End HTML HEADER and COE image -->

<?php

/********* Connects to the database *********/
$conn = ocilogon('girish', 'oracle8i');

/********* Gets data from classmeeting table ***********/
$stmt1 = OCIParse($conn, "select term, department, codenumber, section,counter,
		 count_total, days, starttime, stoptime from classmeeting
		 where 
		    days not like 'TBA%' and 
                    starttime not like 'TBA%' and
		    stoptime not like 'TBA%'
		 ");
 



OCIExecute($stmt1);
$nrows = OCIFetchStatement($stmt1, $results);  //number of rows

$term = $results["TERM"];
$dept = $results["DEPARTMENT"];
$code = $results["CODENUMBER"];
$sect = $results["SECTION"];
$counter = $results["COUNTER"];
$count_total = $results["COUNT_TOTAL"];
$days = $results["DAYS"];
$start_time = $results["STARTTIME"];
$stop_time = $results["STOPTIME"];
ocifreestatement($stmt1);
echo "stmt1 executed\n";
echo "<br>number of rows: $nrows\n";

/********* print table header ********/

print "<center><table border=1 cellpadding=4>\n";
print "<tr align=center bgcolor=afafaf>\n";
print "<th>TERM</th>\n";
print "<th>DEPT</th>\n";
print "<th>CODE</th>\n";
print "<th>SECT</th>\n";
print "<th>COUNTER</th>\n";
print "<th>C_TOTAL</th>\n";
print "<th>DAYS</th>\n";
print "<th>START</th>\n";
print "<th>STOP</th>\n";
print "</tr>\n";


/******** print table rows ***********/

for ($i = 0; $i < $nrows; $i++) {
   print "<tr>\n";
   print "<td>$term[$i]</td>\n";
   print "<td>$dept[$i]</td>\n";
   print "<td>$code[$i]</td>\n";
   print "<td>$sect[$i]</td>\n";
   print "<td>$counter[$i]</td>\n";
   print "<td>$count_total[$i]</td>\n";
   print "<td>$days[$i]</td>\n";
   print "<td>$start_time[$i]</td>\n";
   print "<td>$stop_time[$i]</td>\n";
   print "</tr>\n";
}	
print "</table></center>\n";



/* 
 * Inserting data from classmeeting to schedule_proj table 
 * except for the building and roomnumber 
 */

echo "<br>Start executing stmt2\n";

/*$stmt2 = OCIParse($conn, "insert into schedule_proj values
			('$term[0]','$dept[0]','$code[0]','$sect[0]',
			 '$counter[0]','count_total[0]','$days[0]',
			 '$start_time[0]','$stop_time[0]','ENG','22')");
*/



$stmt2 = OCIParse($conn, "insert into schedule_proj values('994','CE','111','01','1','1','W','1900','1930','ENG','222')");

$exec_result = OCIExecute($stmt2);

echo "<br>End executing stmt2\n";

OCIFreeStatement($stmt2);
echo "<br>execution result: $exec_result";

?>

</body>
</html>






