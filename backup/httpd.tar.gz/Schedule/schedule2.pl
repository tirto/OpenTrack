#!/usr/bin/perl 

use DBI;
use CGI qw/:standard :html3/;
use 5.004;

####################################################################################
# jobManage.pl is the script that lists all kinds of requests:                     #
# new, currently in process and already finished ones                              #
# This is the first script loaded when a manager connects to the JobTrackingSystem #
####################################################################################


#GENERAL CONFIGURATION PARAMETERS

BEGIN 

{
    $ENV{ORACLE_HOME} = "/projects/oracle";
    $ENV{ORACLE_SID} = "rdb1";
}

# We get the name of the remote user as he/she entered it in the login dialog box
#    print h1({-align=>center},"Welcome $ENV{REMOTE_USER}");

#We get the login and password to access the database
#open(FILE,"/home/httpd/.jobDBAccess");
#$DBlogin = <FILE>;
#$DBpassword = <FILE>;
#Let's get rid of that newline character
#chop $DBlogin;
#chop $DBpassword;

$DBlogin = "kindness1";
$DBpassword = "B4U4GETIT";
$term = "002";
@weekDays=("M","T","W","R","F","S","U");

# All info on CGI functions used here can be found @ http://stein.cshl.org/WWW/software/CGI/cgi_docs.html
# They are also featured in the last part of the CGI.pm source itself
print header(),
      start_html(-title=>'College Of Engineering Scheduling System',-BGCOLOR=>'white'),
      h1({-align=>center},"College Of Engineering Scheduling System"),
      p({-align=>center},img{-src=>"http://www.engr.sjsu.edu/images/jpgs/sjsu-coe.jpg"});


# For $dbh and $sth documentation, refer to the DBI module, which is described in 'perldoc DBI'
if (param()) {
  $dbh = DBI->connect('DBI:Oracle:', $DBlogin, $DBpassword, {PrintError=>1,RaiseError=>1}) or die "connecting :   $DBI::errsrtr";
  my $page  = param("page");


    $sth = $dbh->prepare(qq{
    	   SELECT building, roomNumber, capacity
	   FROM room
	   ORDER BY capacity DESC
	   });
    $sth->execute or die "executing: $sth->errstr";

#    print p({-align=>center},'<font size=+1>These are requests that are not currently assigned</font>');

#    print '<table border=0 align=center cellspacing=4>';
#    print Tr({-bgcolor=>"#9999FF"}, td(), td("Date of Request"), td("Name of Issuer"), td("Phone No"), td("Email Address"));
    $roomIndex = 0;
    while (@row = $sth->fetchrow_array) {
      $room[$roomIndex] = $row[0];					#building
      $room[$roomIndex+1] = $row[1];				#roomNumber
      $room[$roomIndex+2] = $row[2];				#capacity
      $room[$roomindex+3] = int($row[2] * 1.05);	#overloaded capacity
      $roomIndex += 4;
    }
    $sth->finish;
    
  for ($weekIndex = 0; $weekIndex <7; $weekIndex++) {
    $sth = $dbh->prepare(qq{
           SELECT co.department, co.codeNumber, co.section, co.activity, co.maxEnrollment, cl.startTime, cl.stopTime, cl.days, LENGTH(cl.days)
           FROM course co, classmeeting cl
           WHERE co.term = $term
           AND co.term = cl.term
           AND co.department = cl.department
           AND co.codenumber = cl.codenumber
           AND co.section = cl.section
           AND INSTR(cl.days, $weekDays[weekIndex],1,1) > 0;
           ORDER BY co.maxEnrollment DESC, co.startTime, LENGTH(cl.days) DESC
           });

    $sth->execute or die "executing: $sth->errstr";

    $meetingIndex = 0;
    while (@row = $sth->fetchrow_array) {
      if ($row[7] != "TBA") {
	$meeting[$meetingIndex] = $row[0];			#department
	$meeting[$meetingIndex+1] = $row[1];		#codeNumber
	$meeting[$meetingIndex+2] = $row[2];		#section
	$meeting[$meetingIndex+3] = $row[3];		#activity
	$meeting[$meetingIndex+4] = $row[4];		#maxEnrollment
	$meeting[$meetingIndex+5] = $row[5];		#startTime
	$meeting[$meetingIndex+6] = $row[6];		#stopTime
	$meeting[$meetingIndex+7] = $row[7];		#days concerned
	$meeting[$meetingIndex+8] = $row[8];		#number of days
	$meetingIndex += 11;						#we set room for cl.building and cl.roomNumber
      }
    }
    $sth->finish;
     
    $nbMeetings = $meetingIndex / 11;
     
    for ($meetingIndex = 0; $meetingIndex < $nbMeetings; $meetingIndex++) {
    }
  }

# Checking the phone value - indeed there could be a bug here in case of somebody's number being '4-0000'
#	if ($row[3] == 0) {
#	    $row[3] = "None";
#	} else {
#	    $row[3] = "4-$row[3]";
#	}
# Substituting spaces with %20 for cgi
#	$temp = $row[2];
#	$temp =~ s/\s/%20/g;
#
#	print Tr(td(a({-href=>"/cgi-bin/JobTrackSuper/jobEdit.pl?page=new&date=$row[0]&client=$temp",
#		       -onMouseOver=>"window.status='Edit and Assign this new request from [$row[2]]'; return true;",
#		       -onMouseOut=>"window.status=' '; return true;"}, img({src=>"/redbullet.gif", border=>0}))),
#		 td("$row[1]"),td("$row[2]"),td({-align=>center}, "$row[3]"),td("$row[4]"));
#    }
#    print '</table>';
print end_html;
































